#include <stdio.h>
#include <string.h>
#include <stdlib.h>

void unlock_vault() {
    char flag[64];
    FILE *f = fopen("flag.txt", "r");
    if (f == NULL) {
        printf("[!] Error: flag.txt missing!\n");
        exit(1);
    }
    fgets(flag, 64, f);
    printf("\n[+] VAULT OPENED: %s\n", flag);
    fflush(stdout);
}

void enter_vault() {
    int secret_key = 0x12345678;
    char username[40];

    printf("--- Digitalni Sef v1.0 ---\n");
    printf("Unesite korisnicko ime: ");
    fflush(stdout);

    gets(username); 

    if (secret_key == 0xdeadbeef) {
        unlock_vault();
    } else {
        printf("\nPristup odbijen!\n");
        printf("Kljuc: 0x%08x | Trazi se: 0xdeadbeef\n", secret_key);
    }
}

int main() {
    setvbuf(stdin, NULL, _IONBF, 0);
    setvbuf(stdout, NULL, _IONBF, 0);
    enter_vault();
    return 0;
}