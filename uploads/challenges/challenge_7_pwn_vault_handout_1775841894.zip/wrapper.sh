#!/bin/bash
/app/zadatak.out