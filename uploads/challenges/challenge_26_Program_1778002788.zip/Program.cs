using System;
using System.IO;
using System.Xml;
using System.Text;

// DotBank XML Profile Parser
// Korisnici mogu submitati XML profil koji server parsira i prikazuje podatke
//
// RANJIVOST: XmlDocument bez XmlResolver=null i DTD zabrane
// procesira External Entity deklaracije i cita lokalne fileove

class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("+=============================================+");
        Console.WriteLine("|      DotBank XML Profile Parser v1.0       |");
        Console.WriteLine("+=============================================+");
        Console.WriteLine();
        Console.WriteLine("  Submit your user profile in XML format.");
        Console.WriteLine("  Fields: username, email, country");
        Console.WriteLine();
        Console.WriteLine("  Example:");
        Console.WriteLine("    <?xml version=\"1.0\"?>");
        Console.WriteLine("    <profile>");
        Console.WriteLine("      <username>john</username>");
        Console.WriteLine("      <email>john@example.com</email>");
        Console.WriteLine("      <country>HR</country>");
        Console.WriteLine("    </profile>");
        Console.WriteLine();
        Console.WriteLine("  Enter XML (single line, end with Enter):");
        Console.Write("> ");
        Console.Out.Flush();

        string? input = Console.ReadLine()?.Trim();

        if (string.IsNullOrEmpty(input))
        {
            Console.WriteLine("[!] No input provided.");
            return;
        }

        ParseProfile(input);
    }

    static void ParseProfile(string xmlInput)
    {
        try
        {
            var doc = new XmlDocument();

            // RANJIVOST: XmlResolver nije postavljen na null
            // i DtdProcessing nije postavljen na Prohibit
            // To omogucuje External Entity (XXE) napade
            doc.XmlResolver = new XmlUrlResolver();  // <-- VULN: dopusta file:// pristup
            // doc.XmlResolver = null;               // <-- OVO bi sprijecilo XXE

            // Ucitavamo XML direktno bez sanitizacije
            doc.LoadXml(xmlInput);

            // Citamo ocekivane fieldove
            string username = doc.SelectSingleNode("/profile/username")?.InnerText ?? "unknown";
            string email    = doc.SelectSingleNode("/profile/email")?.InnerText    ?? "unknown";
            string country  = doc.SelectSingleNode("/profile/country")?.InnerText  ?? "unknown";

            Console.WriteLine();
            Console.WriteLine("[+] Profile parsed successfully:");
            Console.WriteLine($"    Username : {username}");
            Console.WriteLine($"    Email    : {email}");
            Console.WriteLine($"    Country  : {country}");
        }
        catch (XmlException ex)
        {
            Console.WriteLine($"[!] XML parse error: {ex.Message}");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"[!] Error: {ex.Message}");
        }
    }
}
