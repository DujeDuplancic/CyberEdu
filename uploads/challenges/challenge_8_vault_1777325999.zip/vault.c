#include <stdio.h>
#include <string.h>
#include <sys/ptrace.h>
#include <stdlib.h>

unsigned char secret[] = {0x08, 0xb0, 0x20, 0xc9, 0x9b, 0x93, 0x83, 0xdb, 0x8b, 0xd3, 0xb3, 0xab, 0xbb, 0xa3, 0x9b, 0x83, 0xf9};

void anti_debug() {
    if (ptrace(PTRACE_TRACEME, 0, 1, 0) < 0) {
        printf("Debugger detected! Real hackers use their brain.\n");
        exit(1);
    }
}

int main() {
    char input[64];
    anti_debug();
    printf("Enter the Master Key: ");
    scanf("%63s", input);

    if (strlen(input) != 17) {
        printf("Access Denied.\n");
        return 1;
    }

    for(int i = 0; i < 17; i++) {
        unsigned char c = input[i] ^ 0x42;
        input[i] = (c << 3) | (c >> 5);
    }

    if (memcmp(input, secret, 17) == 0) {
        printf("Access Granted!\n");
    } else {
        printf("Access Denied.\n");
    }
    return 0;
}