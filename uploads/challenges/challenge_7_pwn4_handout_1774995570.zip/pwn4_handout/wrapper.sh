#!/bin/sh
cd /ctf || exit 1
exec ./zadatak.out
