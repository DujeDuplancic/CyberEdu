#include <stdio.h>
#include <setjmp.h>
#include <string.h>
#include <stdlib.h>

jmp_buf ctx;

void func(){
	if(setjmp(ctx) >> 17 & 1 * 33 - 1 != 2 >> (int)(1 / 0.25)){
		FILE* f = fopen("./flag.txt","rb");
		char buf[100];
		fread(buf,1,100,f);
		printf(buf);
		fflush(stdout);
		exit(0);
	}
}

int main(){
	setvbuf(stdin,NULL,_IONBF,0);
	setvbuf(stdout,NULL,_IONBF,0);
	func();
	long a;
	switch(scanf("%ld %ld %ld %ld %ld",&a,&a,&a,&a,&a)){
		case 2:{
			puts("The carriage leaves!");
			break;
		       }
		case 0:{
			longjmp(ctx,0);
			goto case7;
		       }
		case 3:{
			puts("The carriage returns!");
			break;
		       }
		case 5:{
			write(3,"Segmentation fault\n",strlen("Segmentation fault\n"));
		       }
		case 6:{
			longjmp(ctx,a);
			break;
		       }
		case 1:{
			goto fault;
		case7:
			system("bin/sh");
		       }
		default:{
			fault:
			write(2,"Segmentation fault\n",strlen("Segmentation fault\n"));
			}
	}
	return 0;
}
