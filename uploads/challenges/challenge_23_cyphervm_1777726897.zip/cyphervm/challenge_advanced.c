/*
 * CTF Challenge: "CIPHER-VM"
 * Difficulty: Very Hard (Advanced)
 * Flag format: CTF{numbers_only}
 *
 * Story:
 * CIPHER is a covert agency that protects its most sensitive activation
 * codes using a custom bytecode virtual machine embedded directly in their
 * verification software. An operative has exfiltrated a copy of the binary.
 * You must reverse-engineer the VM's instruction set, reconstruct the
 * bytecode program it executes, and determine the correct numeric passphrase
 * that causes the VM to output the hidden flag.
 *
 * Correct input: 528491
 * Flag:          CTF{83627150}
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ptrace.h>

/* ================================================================== *
 *  VM Architecture                                                    *
 *  - 8 general-purpose 64-bit registers: R0..R7                     *
 *  - Accumulator (ACC)                                               *
 *  - Program counter (PC)                                            *
 *  - Stack (32 entries)                                              *
 *  - Halt flag                                                       *
 * ================================================================== */

#define VM_REG_COUNT  8
#define VM_STACK_SIZE 32

typedef struct {
    long  reg[VM_REG_COUNT];
    long  acc;
    int   pc;
    int   halted;
    long  stack[VM_STACK_SIZE];
    int   sp;
    int   flag_valid;
} VM;

/* ================================================================== *
 *  Opcodes                                                           *
 * ================================================================== */
typedef enum {
    OP_NOP    = 0x00,
    OP_LOAD   = 0x01,  /* LOAD  Rd, imm       : Rd = imm             */
    OP_MOV    = 0x02,  /* MOV   Rd, Rs        : Rd = Rs              */
    OP_ADD    = 0x03,  /* ADD   Rd, Rs        : Rd = Rd + Rs         */
    OP_SUB    = 0x04,  /* SUB   Rd, Rs        : Rd = Rd - Rs         */
    OP_MUL    = 0x05,  /* MUL   Rd, Rs        : Rd = Rd * Rs         */
    OP_MOD    = 0x06,  /* MOD   Rd, Rs        : Rd = Rd % Rs         */
    OP_XOR    = 0x07,  /* XOR   Rd, Rs        : Rd = Rd ^ Rs         */
    OP_SHR    = 0x08,  /* SHR   Rd, imm       : Rd = Rd >> imm       */
    OP_SHL    = 0x09,  /* SHL   Rd, imm       : Rd = Rd << imm       */
    OP_PUSH   = 0x0A,  /* PUSH  Rs            : stack[sp++] = Rs     */
    OP_POP    = 0x0B,  /* POP   Rd            : Rd = stack[--sp]     */
    OP_CMP    = 0x0C,  /* CMP   Ra, Rb        : acc = (Ra == Rb)?1:0 */
    OP_JNZ    = 0x0D,  /* JNZ   imm           : if acc!=0, PC=imm    */
    OP_JZ     = 0x0E,  /* JZ    imm           : if acc==0, PC=imm    */
    OP_INPUT  = 0x0F,  /* INPUT Rd            : Rd = user_input      */
    OP_OUTPUT = 0x10,  /* OUTPUT Rs           : print Rs             */
    OP_HALT   = 0xFF,  /* HALT                                       */
    OP_SETF   = 0xFE,  /* SETF                : set flag_valid=1     */
} Opcode;

/* ================================================================== *
 *  Instruction encoding: {opcode, arg1, arg2, imm}                  *
 * ================================================================== */
typedef struct {
    unsigned char op;
    unsigned char a1;   /* usually dest register index */
    unsigned char a2;   /* usually src  register index */
    long          imm;  /* immediate value */
} Instr;

/* ================================================================== *
 *  The bytecode program                                              *
 *                                                                    *
 *  What it does (conceptually):                                      *
 *    1. INPUT  R0              ; R0 = user_input                    *
 *    2. LOAD   R1, 528491      ; R1 = expected key                  *
 *    3. CMP    R0, R1          ; acc = (R0 == R1)                   *
 *    4. JZ     <fail>          ; jump to fail if not equal          *
 *                                                                    *
 *  Flag generation pipeline (only reached if correct):              *
 *    5. LOAD   R2, 0x1337      ; R2 = 4919                         *
 *    6. MUL    R0, R2          ; R0 = input * 4919                  *
 *                                = 528491 * 4919 = 2599,568,629    *
 *    7. LOAD   R3, 100000000   ; R3 = 1e8 (8-digit modulus)        *
 *    8. MOD    R0, R3          ; R0 = 2599568629 % 100000000        *
 *                                = 99568629  <- not our flag        *
 *                                                                    *
 *    Let me recompute to hit 83627150:                              *
 *    528491 * 4919 = ?                                              *
 *      528491 * 4000 = 2,113,964,000                               *
 *      528491 *  900 =   475,641,900                               *
 *      528491 *   19 =    10,041,329                               *
 *      total        = 2,599,647,229                                *
 *    2,599,647,229 % 1,000,000,000 = 599,647,229  (9 digits)      *
 *                                                                    *
 *    Use mod 100,000,000 (8 digits):                               *
 *    2,599,647,229 % 100,000,000 = 99,647,229  (not target)       *
 *                                                                    *
 *    Use XOR step to reach 83627150:                               *
 *    seed  = 528491                                                 *
 *    step1 = seed ^ 0xDEAD   (0xDEAD = 57005)                     *
 *          = 528491 ^ 57005                                         *
 *    528491 = 0x8114B                                               *
 *     57005 = 0x0DEAD                                               *
 *    XOR    = 0x8EF06 = 585478 ... not 8 digits                    *
 *                                                                    *
 *    Multi-step to get 83627150:                                    *
 *    R0 = input = 528491                                            *
 *    R0 = R0 * 3       = 1585473                                   *
 *    R0 = R0 + 0x4321  = 1585473 + 17185 = 1602658                *
 *    R0 = R0 XOR 0xBEEF = 1602658 ^ 48879                         *
 *       1602658 = 0x187762                                          *
 *        48879  = 0x00BEEF                                          *
 *    XOR = 0x18398D = 1588109                                      *
 *    R0 = R0 * 53 = 1588109 * 53 = 84,169,777  (8 digits!)        *
 *    Not 83627150 — let me use exact target:                       *
 *                                                                    *
 *  Redefine: we pick the transformations and DECLARE the flag.     *
 *  Transform chain that yields 83627150:                            *
 *    R0 = 528491                                                    *
 *    R0 = R0 XOR 0x7FFFF  (R0 = 528491^524287 = 0x81A8C^0x7FFFF   *
 *       528491 = 0x81148 ... let me be careful                     *
 *       528491 in hex: 528491 / 16 = 33030 r 11(B)                *
 *       33030  / 16 = 2064  r 6                                    *
 *       2064   / 16 = 129   r 0                                    *
 *       129    / 16 = 8     r 1                                    *
 *       8      / 16 = 0     r 8                                    *
 *       => 0x8106B                                                  *
 *    0x8106B ^ 0x7FFFF = 0xFEF94 = 1044372                        *
 *    1044372 * 80 = 83,549,760 — close but not 83627150            *
 *                                                                    *
 *  Simplest approach: define exact constants that produce target.  *
 *  528491 * 158 = 83502578  (not exact)                            *
 *  83627150 / 528491 = 158.23... not integer                       *
 *                                                                    *
 *  Use additive: seed=528491, A=528491*157=82997287, A+629863=83627150  *
 *  629863 is the additive constant                                  *
 *                                                                    *
 *  Final pipeline:                                                  *
 *    R0 = input (528491)                                            *
 *    R1 = 157                                                       *
 *    R0 = R0 * R1   = 82,997,287                                   *
 *    R2 = 629863                                                    *
 *    R0 = R0 + R2   = 83,627,150   ✓                               *
 *    SETF                                                           *
 *    OUTPUT R0      -> prints 83627150                              *
 * ================================================================== */

static const Instr program[] = {
    /* 0 */ { OP_INPUT,  0, 0, 0 },         /* R0 = input           */
    /* 1 */ { OP_LOAD,   1, 0, 528491 },    /* R1 = 528491 (key)    */
    /* 2 */ { OP_CMP,    0, 1, 0 },         /* acc = (R0==R1)?1:0   */
    /* 3 */ { OP_JZ,     0, 0, 12 },        /* if acc==0 goto [12]  */

    /* -- Flag generation pipeline (PC 4..11) -- */
    /* 4 */ { OP_LOAD,   1, 0, 157 },       /* R1 = 157             */
    /* 5 */ { OP_MUL,    0, 1, 0 },         /* R0 = R0 * R1         */
    /* 6 */ { OP_LOAD,   2, 0, 629863 },    /* R2 = 629863          */
    /* 7 */ { OP_ADD,    0, 2, 0 },         /* R0 = R0 + R2         */

    /* Checksum verification sub-step */
    /* 8 */ { OP_LOAD,   3, 0, 42 },        /* R3 = 42 (marker)     */
    /* 9 */ { OP_XOR,    3, 3, 0 },         /* R3 = R3 ^ R3 = 0     */
    /*10 */ { OP_CMP,    3, 3, 0 },         /* acc = 1 (always)     */
    /*11 */ { OP_JNZ,    0, 0, 15 },        /* acc==1 always; jump to SETF */

    /* -- Fail path (PC 12..13) -- */
    /*12 */ { OP_LOAD,   7, 0, 0 },         /* R7 = 0 (sentinel)    */
    /*13 */ { OP_HALT,   0, 0, 0 },

    /* -- This instruction is jumped-to by JZ @11 (never reached) -- */
    /*14 */ { OP_NOP,    0, 0, 0 },

    /* -- Success output (PC 15..16) -- */
    /*15 */ { OP_SETF,   0, 0, 0 },         /* flag_valid = 1       */
    /*16 */ { OP_OUTPUT, 0, 0, 0 },         /* print R0             */
    /*17 */ { OP_HALT,   0, 0, 0 },
};

#define PROG_LEN  (int)(sizeof(program)/sizeof(program[0]))

/* ================================================================== *
 *  VM Execution Engine                                               *
 * ================================================================== */

static void vm_init(VM *vm) {
    memset(vm, 0, sizeof(VM));
}

static void vm_run(VM *vm, long user_input) {
    while (!vm->halted && vm->pc < PROG_LEN) {
        const Instr *ins = &program[vm->pc];
        vm->pc++;

        switch (ins->op) {
        case OP_NOP:
            break;

        case OP_LOAD:
            vm->reg[ins->a1] = ins->imm;
            break;

        case OP_MOV:
            vm->reg[ins->a1] = vm->reg[ins->a2];
            break;

        case OP_ADD:
            vm->reg[ins->a1] += vm->reg[ins->a2];
            break;

        case OP_SUB:
            vm->reg[ins->a1] -= vm->reg[ins->a2];
            break;

        case OP_MUL:
            vm->reg[ins->a1] *= vm->reg[ins->a2];
            break;

        case OP_MOD:
            if (vm->reg[ins->a2] != 0)
                vm->reg[ins->a1] %= vm->reg[ins->a2];
            break;

        case OP_XOR:
            vm->reg[ins->a1] ^= vm->reg[ins->a2];
            break;

        case OP_SHR:
            vm->reg[ins->a1] >>= (int)ins->imm;
            break;

        case OP_SHL:
            vm->reg[ins->a1] <<= (int)ins->imm;
            break;

        case OP_PUSH:
            if (vm->sp < VM_STACK_SIZE)
                vm->stack[vm->sp++] = vm->reg[ins->a1];
            break;

        case OP_POP:
            if (vm->sp > 0)
                vm->reg[ins->a1] = vm->stack[--vm->sp];
            break;

        case OP_CMP:
            vm->acc = (vm->reg[ins->a1] == vm->reg[ins->a2]) ? 1 : 0;
            break;

        case OP_JNZ:
            if (vm->acc != 0)
                vm->pc = (int)ins->imm;
            break;

        case OP_JZ:
            if (vm->acc == 0)
                vm->pc = (int)ins->imm;
            break;

        case OP_INPUT:
            vm->reg[ins->a1] = user_input;
            break;

        case OP_OUTPUT:
            if (vm->flag_valid) {
                printf("CIPHER-VM: Access granted.\n");
                printf("Activation code verified. Flag: CTF{%ld}\n",
                       vm->reg[ins->a1]);
            }
            break;

        case OP_SETF:
            vm->flag_valid = 1;
            break;

        case OP_HALT:
            vm->halted = 1;
            break;

        default:
            vm->halted = 1;
            break;
        }
    }
}

/* ================================================================== *
 *  Light anti-debug (optional, easily bypassed)                     *
 * ================================================================== */
static int anti_debug_check(void) {
    /* ptrace self-check */
    if (ptrace(PTRACE_TRACEME, 0, NULL, NULL) == -1) {
        return 1;
    }
    ptrace(PTRACE_DETACH, 0, NULL, NULL);
    return 0;
}

/* ================================================================== *
 *  Entry point                                                       *
 * ================================================================== */
int main(void) {
    char buf[64];
    long input;

    printf("=== CIPHER Agency Verification Terminal ===\n");
    printf("Protocol: VM-EXEC / Bytecode v4\n");
    printf("Enter numeric activation code: ");
    fflush(stdout);

    if (anti_debug_check()) {
        printf("Debugger detected. Protocol locked.\n");
        return 1;
    }

    if (fgets(buf, sizeof(buf), stdin) == NULL) {
        return 1;
    }
    buf[strcspn(buf, "\n")] = '\0';
    input = atol(buf);

    VM vm;
    vm_init(&vm);
    vm_run(&vm, input);

    if (!vm.flag_valid) {
        printf("CIPHER-VM: Verification failed. Incorrect code.\n");
    }

    return 0;
}
