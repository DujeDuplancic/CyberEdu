/*
 * CTF Challenge: "The Intern's Secret"
 * Difficulty: Easy
 * Flag format: CTF{numbers_only}
 *
 * Story:
 * A junior developer at MegaCorp accidentally left a hidden flag in a
 * validation binary before pushing to production. Their senior colleague
 * noticed something odd in the binary and challenged you to find it.
 * The intern thought XOR-encoding the digits would be "secure enough."
 * Spoiler: it wasn't.
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

/* XOR key used to encode each digit of the flag */
#define XOR_KEY 0x5A

/*
 * The flag is: CTF{31415926}
 * Each digit ASCII value XOR'd with XOR_KEY (0x5A):
 *   '3'=0x33 ^ 0x5A = 0x69
 *   '1'=0x31 ^ 0x5A = 0x6B
 *   '4'=0x34 ^ 0x5A = 0x6E
 *   '1'=0x31 ^ 0x5A = 0x6B
 *   '5'=0x35 ^ 0x5A = 0x6F
 *   '9'=0x39 ^ 0x5A = 0x63
 *   '2'=0x32 ^ 0x5A = 0x68
 *   '6'=0x36 ^ 0x5A = 0x6C
 */
static const unsigned char encoded_flag[] = {
    0x69, 0x6B, 0x6E, 0x6B, 0x6F, 0x63, 0x68, 0x6C
};
static const int FLAG_LEN = 8;

/* Decode and print the flag */
static void reveal_flag(void) {
    char flag[64];
    int i;

    strcpy(flag, "CTF{");
    for (i = 0; i < FLAG_LEN; i++) {
        flag[4 + i] = (char)(encoded_flag[i] ^ XOR_KEY);
    }
    flag[4 + FLAG_LEN] = '}';
    flag[4 + FLAG_LEN + 1] = '\0';

    printf("Access granted! Flag: %s\n", flag);
}

/* Simple numeric password check — password is 1337 */
static int check_password(const char *input) {
    int val = atoi(input);
    return (val == 1337);
}

int main(int argc, char *argv[]) {
    char buf[64];

    printf("=== MegaCorp Internal Validator ===\n");
    printf("Enter access code: ");

    if (fgets(buf, sizeof(buf), stdin) == NULL) {
        return 1;
    }

    /* Strip newline */
    buf[strcspn(buf, "\n")] = '\0';

    if (check_password(buf)) {
        reveal_flag();
    } else {
        printf("Access denied.\n");
    }

    return 0;
}
