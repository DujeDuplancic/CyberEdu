# CTF — RustBank Transfer 🦀💸

**Difficulty:** Easy-Medium  
**Category:** Binary Exploitation / Logic Bug  

---

## Priča

> *"Built with Rust — sigurno kao trezor."*
>
> Inženjeri u RustBanku su ponosni: nema `gets()`, nema buffer overflowa,
> nema nesigurnog C koda. Čisti, moderni Rust.
>
> Samo... zaboravili su na jedan mali detalj u obradi transakcija.
>
> Tvoj saldo je $100. Maksimalni transfer je $100.
> Ali banka čuva nešto vrijedno iza te provjere.
>
> Možeš li izvući više nego što imaš?
>
> `nc <host> 1337`
>
> **Files:** `zadatak` (binary), `main.rs` (source)

---

## Build i pokretanje (lokalno)

```bash
cargo build --release
cp target/release/zadatak .
./zadatak
```

### Docker

```bash
docker build -t rustbank2 .
docker run -p 1337:1337 rustbank2
nc localhost 1337
```
