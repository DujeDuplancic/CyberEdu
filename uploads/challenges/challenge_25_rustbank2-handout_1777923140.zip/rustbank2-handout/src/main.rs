use std::io::{self, BufRead, Write};

const BALANCE: u32 = 100;
const MAX_TRANSFER: u32 = 100;

fn print_flag() {
    let flag = std::fs::read_to_string("flag.txt")
        .unwrap_or_else(|_| "CTF{test_local_flag}\n".to_string());
    println!("\n╔══════════════════════════════════════╗");
    println!("║   💸  TRANSFER APPROVED!             ║");
    println!("║   Vault access granted.              ║");
    println!("╚══════════════════════════════════════╝");
    println!("\n[+] FLAG: {}", flag.trim());
    io::stdout().flush().unwrap();
}

fn main() {
    let stdin = io::stdin();

    println!("╔══════════════════════════════════════╗");
    println!("║        RustBank Transfer v2.0  🏦    ║");
    println!("╚══════════════════════════════════════╝");
    println!();
    println!("  Vaš saldo:           ${}", BALANCE);
    println!("  Maksimalni transfer: ${}", MAX_TRANSFER);
    println!();
    print!("  Unesite iznos transakcije: $");
    io::stdout().flush().unwrap();

    let mut line = String::new();
    stdin.lock().read_line(&mut line).unwrap();
    let input = line.trim();

    // Parsiramo kao u64 da prihvatimo velike brojeve...
    let amount_u64: u64 = match input.parse() {
        Ok(v) => v,
        Err(_) => {
            println!("\n[-] Greška: neispravan unos.");
            return;
        }
    };

    // RANJIVOST: castamo u64 → u32 (truncation!)
    // Npr. 4294967396 = 0x1_0000_0064 → 0x64 = 100 (prođe validaciju!)
    let amount = amount_u64 as u32;

    println!("\n  [*] Obrađujem transfer od ${} ...", amount);

    // Validacija — ali radi na već trunciranom u32!
    if amount < 1 || amount > MAX_TRANSFER {
        println!("  [-] Transfer odbijen: iznos mora biti između $1 i ${}.", MAX_TRANSFER);
        println!("      (Internim sustavom: ${})", amount);
        return;
    }

    // Saldo check
    if amount > BALANCE {
        println!("  [-] Transfer odbijen: nedovoljno sredstava.");
        return;
    }

    // Sve provjere prošle — odobravamo!
    print_flag();
}
