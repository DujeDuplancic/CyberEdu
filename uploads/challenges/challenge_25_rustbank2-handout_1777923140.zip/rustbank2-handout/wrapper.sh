#!/bin/bash
cd /
timeout 30 /zadatak
