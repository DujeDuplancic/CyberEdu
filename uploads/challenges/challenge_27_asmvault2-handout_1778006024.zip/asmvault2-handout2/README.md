# CTF — ASM Vault Security v2.0 🔐

**Difficulty:** Hard
**Category:** Binary Exploitation

---

## Priča

> *"No C. No libc. No mercy."*
>
> Ovaj vault je napisan u čistom x86-64 assembly jeziku.
> Developeri su ponosni — nema C runtime-a, nema libc-a.
>
> Ali syscall koji čita input ne provjerava duljinu...
>
> Postoji funkcija koja nikad nije pozvana iz _start.
> Pronađi je. Pozovi je.
>
> `nc <host> 4444`
>
> **Files:** `vault` (binary), `vault.asm` (source)

---

## Lokalni build

```bash
nasm -f elf64 vault.asm -o vault.o
ld vault.o -o vault
./vault
```
