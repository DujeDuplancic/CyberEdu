; ASM Vault Security v2.0
; x86-64 NASM — čisti assembly, bez C runtime
;
; Stack layout u check_code:
;   [rsp+0  .. rsp+31]  buf (32 bajta)
;   [rsp+32 .. rsp+39]  saved rbp (8 bajta)
;   [rsp+40 .. rsp+47]  return address  <-- overwritamo ovo!

section .data
    banner1     db "+=======================================+", 10, 0
    banner2     db "|      ASM VAULT SECURITY  v2.0        |", 10, 0
    banner3     db "|   Written in pure x86-64 Assembly    |", 10, 0
    banner4     db "+=======================================+", 10, 0
    banner5     db "|  No C. No libc. No mercy.            |", 10, 0
    banner6     db "+=======================================+", 10, 10, 0
    prompt      db "Enter access code: ", 0
    denied      db 10, "Access denied.", 10, 0
    granted1    db 10, "+---------------------------------------+", 10, 0
    granted2    db "|   ACCESS GRANTED. VAULT UNLOCKED.    |", 10, 0
    granted3    db "+---------------------------------------+", 10, 0
    flag_label  db "FLAG: ", 0
    flag_path   db "/flag.txt", 0
    err_msg     db "[!] Cannot open flag.txt", 10, 0

section .bss
    flag_buf    resb 64

section .text
    global _start

; --- helper: print null-terminated string (rdi = ptr) ---
print_str:
    push rbx
    mov rbx, rdi
.len_loop:
    cmp byte [rbx], 0
    je .do_write
    inc rbx
    jmp .len_loop
.do_write:
    sub rbx, rdi
    mov rdx, rbx        ; length
    mov rsi, rdi        ; buf
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    pop rbx
    ret

; --- helper: print buffer of known length (rsi=buf, rdx=len) ---
print_buf:
    mov rdi, 1
    mov rax, 1
    syscall
    ret

; ============================================================
; unlock_vault — nikad pozvana iz maina, ali postoji u binarnom
; ============================================================
unlock_vault:
    ; print granted banner
    mov rdi, granted1
    call print_str
    mov rdi, granted2
    call print_str
    mov rdi, granted3
    call print_str

    ; open("/flag.txt", O_RDONLY)
    mov rax, 2              ; sys_open
    mov rdi, flag_path
    xor rsi, rsi            ; O_RDONLY
    xor rdx, rdx
    syscall
    cmp rax, 0
    jl .err

    ; read(fd, flag_buf, 64)
    mov rdi, rax            ; fd
    mov rax, 0              ; sys_read
    mov rsi, flag_buf
    mov rdx, 64
    syscall
    mov r12, rax            ; bytes read

    ; close(fd)
    mov rax, 3
    syscall

    ; print "FLAG: "
    mov rdi, flag_label
    call print_str

    ; print flag contents
    mov rsi, flag_buf
    mov rdx, r12
    call print_buf

    ; newline
    mov rax, 1
    mov rdi, 1
    mov rsi, banner1        ; reuse newline char
    mov rdx, 1
    syscall

    ; exit(0)
    mov rax, 60
    xor rdi, rdi
    syscall

.err:
    mov rdi, err_msg
    call print_str
    mov rax, 60
    mov rdi, 1
    syscall

; ============================================================
; check_code — ranjiva funkcija
; ============================================================
check_code:
    push rbp
    mov rbp, rsp
    sub rsp, 32             ; buf[32]

    ; print prompt
    mov rdi, prompt
    call print_str

    ; read(0, buf, 256) — RANJIVOST: čita 256 u buffer od 32!
    mov rax, 0              ; sys_read
    mov rdi, 0              ; stdin
    lea rsi, [rbp-32]       ; buf
    mov rdx, 256            ; previše!
    syscall

    ; print "Access denied."
    mov rdi, denied
    call print_str

    leave
    ret

; ============================================================
; _start
; ============================================================
_start:
    ; print banner
    mov rdi, banner1
    call print_str
    mov rdi, banner2
    call print_str
    mov rdi, banner3
    call print_str
    mov rdi, banner4
    call print_str
    mov rdi, banner5
    call print_str
    mov rdi, banner6
    call print_str

    call check_code

    ; exit(0)
    mov rax, 60
    xor rdi, rdi
    syscall
