#!/bin/bash
cd /
timeout 60 /vault
