Challenge 12 - "The Gatekeeper"
Category: Reverse Engineering | Difficulty: Medium
=========================================

A suspicious binary was found on a compromised server.
Analyze it and find the key it accepts.

Files:
  crackme.pyc  - The binary to reverse
  hint.txt     - Some hints

Submit the correct key as your flag.
