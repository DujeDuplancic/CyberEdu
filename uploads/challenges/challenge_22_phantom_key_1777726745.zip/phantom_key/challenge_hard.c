/*
 * CTF Challenge: "Phantom Key"
 * Difficulty: Hard
 * Flag format: CTF{numbers_only}
 *
 * Story:
 * A sophisticated piece of malware was discovered on an air-gapped server.
 * Forensic analysts believe it stores a stolen numeric key inside itself,
 * reconstructing it at runtime only when certain environmental conditions
 * are met. The malware actively resists debugging attempts. Your mission:
 * bypass its defenses and recover the hidden numeric key before it's used.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ptrace.h>
#include <time.h>
#include <unistd.h>
#include <errno.h>

/* ------------------------------------------------------------------ *
 * Anti-debugging layer 1: ptrace self-attach                         *
 * If a debugger is already attached, ptrace(PTRACE_TRACEME) returns  *
 * -1 with errno == EPERM.                                            *
 * ------------------------------------------------------------------ */
static int is_debugged_ptrace(void) {
    errno = 0;
    long r = ptrace(PTRACE_TRACEME, 0, NULL, NULL);
    if (r == -1 && errno == EPERM) {
        return 1;
    }
    if (r == 0) {
        ptrace(PTRACE_DETACH, 0, NULL, NULL);
    }
    return 0;
}

/* ------------------------------------------------------------------ *
 * Anti-debugging layer 2: /proc/self/status TracerPid                *
 * ------------------------------------------------------------------ */
static int is_debugged_proc(void) {
    FILE *f = fopen("/proc/self/status", "r");
    if (!f) return 0;
    char line[256];
    while (fgets(line, sizeof(line), f)) {
        if (strncmp(line, "TracerPid:", 10) == 0) {
            int tracer = atoi(line + 10);
            fclose(f);
            return (tracer != 0);
        }
    }
    fclose(f);
    return 0;
}

/* ------------------------------------------------------------------ *
 * Anti-debugging layer 3: timing check                               *
 * A gap >500 ms between checkpoints suggests single-stepping.        *
 * ------------------------------------------------------------------ */
static struct timespec g_ts;

static void timing_start(void) {
    clock_gettime(CLOCK_MONOTONIC, &g_ts);
}

static int timing_suspicious(void) {
    struct timespec now;
    clock_gettime(CLOCK_MONOTONIC, &now);
    long ms = (now.tv_sec - g_ts.tv_sec) * 1000
            + (now.tv_nsec - g_ts.tv_nsec) / 1000000;
    return (ms > 500);
}

/* ------------------------------------------------------------------ *
 * Flag reconstruction via function pointers                          *
 *                                                                     *
 * Flag: CTF{72519364}                                                *
 *                                                                     *
 * Stored as two encoded chunks:                                       *
 *   CHUNK_A_ENC = 72519 + 4369 = 76888                              *
 *   CHUNK_B_ENC = 364   + 2748 = 3112                               *
 *                                                                     *
 * decode_chunk_a(76888) = 76888 - 4369 = 72519                      *
 * decode_chunk_b(3112)  = 3112  - 2748 = 364                        *
 * ------------------------------------------------------------------ */
typedef long (*decode_fn)(long);

static long decode_chunk_a(long enc) { return enc - 4369L; }
static long decode_chunk_b(long enc) { return enc - 2748L; }

static const long CHUNK_A_ENC = 76888L;
static const long CHUNK_B_ENC = 3112L;

static void reconstruct_flag(void) {
    decode_fn pipeline[2];
    pipeline[0] = decode_chunk_a;
    pipeline[1] = decode_chunk_b;

    long part1 = pipeline[0](CHUNK_A_ENC);
    long part2 = pipeline[1](CHUNK_B_ENC);

    printf("Phantom key recovered: CTF{%ld%ld}\n", part1, part2);
}

static void dispatch(int live) {
    if (live) {
        reconstruct_flag();
    } else {
        printf("Runtime integrity compromised.\n");
    }
}

int main(void) {
    printf("=== Phantom Secure Runtime v0.9 ===\n");

    if (is_debugged_ptrace()) {
        printf("Integrity violation detected. Terminating.\n");
        return 1;
    }

    timing_start();

    if (is_debugged_proc()) {
        printf("Environment check failed. Terminating.\n");
        return 1;
    }

    if (timing_suspicious()) {
        printf("Timing anomaly detected. Terminating.\n");
        return 1;
    }

    volatile unsigned int ctrl = 0xDEADBEEF;
    volatile unsigned int mask = 0xDEADBEEF;
    dispatch((int)((ctrl ^ mask) == 0));

    return 0;
}
